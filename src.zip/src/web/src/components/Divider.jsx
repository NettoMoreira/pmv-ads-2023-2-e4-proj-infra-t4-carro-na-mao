export default function Divider() {
  return <div className=" h-[1px] bg-slate-300"></div>;
}
